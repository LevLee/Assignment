﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WaterBillingProgram
{
    public class Customer
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public int PeopleCount { get; set; }
        public double LastReading { get; set; }
        public double CurrentReading { get; set; }
        public double Consumption { get { return CurrentReading - LastReading; } }
        public double TotalBill { get; set; }
    }

    public static class BillingCalculator
    {
        private const double VAT = 0.10;
        private static readonly Dictionary<string, double> Rates = new Dictionary<string, double>
        {
            { "Administrative", 9955 },
            { "Production", 11615 },
            { "Business", 22068 }
        };

        public static double CalculateHouseholdBill(int people, double consumption)
        {
            double[] limits = { 10, 20, 30 };
            double[] rates = { 5973, 7052, 8699, 15929 };
            double bill = 0;
            double consumptionPerPerson = consumption / people;
            double remaining = consumption;

            for (int i = 0; i < limits.Length && remaining > 0; i++)
            {
                double tierVolume = Math.Min(remaining, limits[i] * people);
                bill += tierVolume * rates[i];
                remaining -= tierVolume;
            }

            if (remaining > 0)
            {
                bill += remaining * rates[rates.Length - 1];
            }
            return bill * 1.10; // Includes environment protection fee
        }

        public static double CalculateNonHouseholdBill(string type, double consumption)
        {
            if (Rates.ContainsKey(type))
            {
                double basePrice = consumption * Rates[type];
                return basePrice * 1.10; // Includes environment protection fee
            }
            throw new ArgumentException("Invalid customer type");
        }
    }

    class Program
    {
        static List<Customer> customers = new List<Customer>();

        static void Main()
        {
            Console.Write("Enter the number of customers: ");
            int customerCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < customerCount; i++)
            {
                Console.WriteLine($"\nCustomer {i + 1}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Type (Household/Administrative/Production/Business): ");
                string type = Console.ReadLine();
                Console.Write("Last month reading: ");
                double lastReading = double.Parse(Console.ReadLine());
                Console.Write("Current reading: ");
                double currentReading = double.Parse(Console.ReadLine());

                double totalBill = 0;
                int people = 0;

                if (type.Equals("Household", StringComparison.OrdinalIgnoreCase))
                {
                    Console.Write("Number of people: ");
                    people = int.Parse(Console.ReadLine());
                    totalBill = BillingCalculator.CalculateHouseholdBill(people, currentReading - lastReading);
                }
                else
                {
                    totalBill = BillingCalculator.CalculateNonHouseholdBill(type, currentReading - lastReading);
                }

                totalBill *= 1.10; // Add VAT (10%)

                customers.Add(new Customer
                {
                    Name = name,
                    Type = type,
                    LastReading = lastReading,
                    CurrentReading = currentReading,
                    PeopleCount = people,
                    TotalBill = totalBill
                });
            }
            DisplayInvoices();
        }

        static void DisplayInvoices()
        {
            Console.WriteLine("\nInvoices:");
            foreach (var c in customers.OrderBy(c => c.Name))
            {
                Console.WriteLine($"Name: {c.Name}, Type: {c.Type}, Consumption: {c.Consumption} m³, Bill: {c.TotalBill:C}");
            }
        }
    }
}